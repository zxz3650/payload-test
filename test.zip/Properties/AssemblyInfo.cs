using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("BitSentry Anti-Exploit Detect Log")]
[assembly: AssemblyDescription("BitSentry Anti-Exploit Detect Log")]
[assembly: AssemblyCompany("BLACKFORT SECURITY, INC.")]
[assembly: AssemblyProduct("BitSentry Anti-Exploit Detect Log")]
[assembly: AssemblyCopyright("Copyright 2017© BLACKFORT SECURITY Inc. All rights reserved.")]
[assembly: AssemblyTrademark("BLACKFORT SECURITY.INC,")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("11.0.0.1")]
[assembly: AssemblyFileVersion("11.0.0.1")]