using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("HncUpdateService")]
[assembly: AssemblyDescription("HncUpdateService")]
[assembly: AssemblyCompany("HANCOM.INC,")]
[assembly: AssemblyProduct("HncUpdateService")]
[assembly: AssemblyCopyright("Copyright 2017© Hancom Inc. All rights reserved.")]
[assembly: AssemblyTrademark("HANCOM.INC,")]

[assembly: ComVisible(false)]

[assembly: AssemblyVersion("11.0.0.2")]
[assembly: AssemblyFileVersion("11.0.0.2")]